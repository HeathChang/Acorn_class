package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dto.MemberDTO;
import com.service.MemberSerivce;

@Controller
public class MemberController {
	@Autowired
	MemberSerivce service;
	
	@RequestMapping(value = "idDuplicateCheck", produces="text/plain;charset=UTF-8")//한글처리 	
	public @ResponseBody String idDuplicatedCheck(@RequestParam("id") String userid) {
		//비동기 방식 요청에 대한 mesg를 문자열로 전송 
		MemberDTO dto= service.myPage(userid);
		System.out.println("idDuplicatedCheck====   "+ userid);
		System.out.println(dto);
		String mesg="아이디 사용가능";
		if(dto != null) {//db에 같은 id가 존재
			mesg="아이디 중복";
		}
		return mesg;  //view페이지가 아닌 mesg문자열 전송 
	}
	
	
	
	
	
	
	
	@RequestMapping(value = "/loignCheck/myPage")
	public String myPage(HttpSession session) {
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String userid= dto.getUserid();
		dto= service.myPage(userid);
		session.setAttribute("login", dto);
		return "redirect:../myPage"; //servlet-context에등록
	}
	@RequestMapping(value = "/memberAdd")
	public String memberAdd(MemberDTO m,Model model) {
		service.memberAdd(m);
		model.addAttribute("success", "회원가입성공");
		return "main";
	}
}
